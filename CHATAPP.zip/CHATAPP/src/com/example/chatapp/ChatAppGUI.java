/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;



/**
 *
 * @author hifi
 */
public class ChatAppGUI {
     public static void main(String[] args) {
        login login = new login();

            // --- Colour settings ---
        Color orangeBg = Color.ORANGE;
        Color whiteText = Color.WHITE;
        Color darkRed = Color.decode("#8B0000"); // darker red for border/trim

        // Apply colours to JOptionPane
        UIManager.put("OptionPane.background", orangeBg);
        UIManager.put("Panel.background", orangeBg);
        UIManager.put("OptionPane.messageForeground", whiteText);
        UIManager.put("OptionPane.border", new LineBorder(darkRed, 3));

        // === Registration loop ===
        while (true) {
            JOptionPane.showMessageDialog(
                    null,
                    "*** Create Your Profile ***\nFollow the prompts to set up your account.",
                    "Registration",
                    JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                    null,
                    "Choose a username (must contain '_' and be no longer than 5 characters):",
                    "Username",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return;

            String password = JOptionPane.showInputDialog(
                    null,
                    "Create a password (at least 8 characters with a capital letter, a number and a special character):",
                    "Password",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(
                    null,
                    "Enter your cellphone number with the international code (e.g. ‪+27838968976‬):",
                    "Cellphone",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(
                    null,
                    regMessage,
                    "Registration Status",
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (regMessage.equals("Registration successful.")) {
                break; // proceed to login
            }
            // otherwise loop back
        }

        // === Login loop ===
        while (true) {
            JOptionPane.showMessageDialog(
                    null,
                    "*** Sign In ***\nEnter your details to access your account.",
                    "Login",
                    JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                    null,
                    "Username:",
                    "Login",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return;

            String password = JOptionPane.showInputDialog(
                    null,
                    "Password:",
                    "Login",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());

            JOptionPane.showMessageDialog(
                    null,
                    msg,
                    ok ? "Login Successful" : "Login Failed",
                    ok ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
            );

            if (ok) {
                break; // stop after successful login
            }
            // otherwise repeat login attempt
        }
    }
}