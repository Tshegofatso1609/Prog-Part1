/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;





/**
 *
 * @author hifi
 */
public class ChatAppGUI {
  public static void main(String[] args) {
        // === GLOBAL UI STYLING ===
        Color orange = new Color(255, 140, 0);
        Color darkRed = new Color(139, 0, 0);

        UIManager.put("OptionPane.background", orange);
        UIManager.put("Panel.background", orange);
        UIManager.put("OptionPane.messageForeground", Color.WHITE);
        UIManager.put("OptionPane.border", new LineBorder(darkRed, 4));
        UIManager.put("Button.background", Color.WHITE);
        UIManager.put("Button.foreground", Color.BLACK);

        // === LOGO POPUP ===
        JLabel logoLabel = new JLabel(
            "<html><center>"
            + "<span style='font-size:26pt; color:white; font-weight:bold;'>TTMQuickChat 💬</span><br><br>"
            + "<span style='font-size:14pt; color:white;'>Where Every Message Matters 💫</span>"
            + "</center></html>"
        );
        JOptionPane.showMessageDialog(null, logoLabel, "Welcome to TTMQuickChat", JOptionPane.INFORMATION_MESSAGE);

        login login = new login();

        // === REGISTRATION ===
        while (true) {
            JOptionPane.showMessageDialog(null, "📝 Let's set up your account!\nPlease enter your details carefully.");

            String username = JOptionPane.showInputDialog(null, "👤 Create a username (include '_' and max 5 characters):");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "🔑 Create a strong password (min 8 chars, capital, number, special):");
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(null, "📱 Enter your cellphone (e.g. ‪+27838968976‬):");
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(null, regMessage);

            if (regMessage.equals("Registration successful.")) break;
        }

        // === LOGIN ===
        boolean loggedIn = false;
        String loggedUsername = null;
        while (!loggedIn) {
            JOptionPane.showMessageDialog(null, "🔐 Please log in to continue.");
            String username = JOptionPane.showInputDialog(null, "👤 Enter your username:");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "🔑 Enter your password:");
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());
            JOptionPane.showMessageDialog(null, msg);

            if (ok) {
                loggedIn = true;
                loggedUsername = username.trim();
            }
        }

        // === WELCOME MESSAGE ===
        JOptionPane.showMessageDialog(null, "🎉 Welcome back, " + loggedUsername + "!\n\n✨ Chat. Connect. Create Moments. ✨");

        // === NUMBER OF MESSAGES ===
        int messagesToEnter = 0;
        while (messagesToEnter <= 0) {
            String nm = JOptionPane.showInputDialog(null, "💬 How many messages would you like to send today?");
            if (nm == null) return;
            try {
                messagesToEnter = Integer.parseInt(nm.trim());
                if (messagesToEnter <= 0) {
                    JOptionPane.showMessageDialog(null, "⚠ Please enter a positive number.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "❌ That doesn’t look like a valid number. Try again.");
            }
        }

        List<Message> allMessages = new ArrayList<>();
        boolean quit = false;
        int messagesSent = 0;  // keep track of how many messages have been sent

        // === MAIN MENU LOOP ===
        while (!quit) {
            String menu = "📋 Choose an option:\n"
                    + "1️⃣ Send Messages\n"
                    + "2️⃣ View Recent Messages\n"
                    + "3️⃣ Exit";
            String choice = JOptionPane.showInputDialog(null, menu);
            if (choice == null) return;

            switch (choice.trim()) {
                case "1":
                    if (messagesSent >= messagesToEnter) {
                        JOptionPane.showMessageDialog(null, "⚠ You’ve reached your message limit of " + messagesToEnter + "!");
                        break;
                    }

                    for (int i = messagesSent; i < messagesToEnter; i++) {
                        String recipient = JOptionPane.showInputDialog(null,
                                String.format("📨 Enter recipient for message %d (include +27):", i + 1));
                        if (recipient == null) break;

                        String messageText = JOptionPane.showInputDialog(null, "✍ Type your message (max 250 chars):");
                        if (messageText == null) break;

                        if (messageText.length() > 250) {
                            JOptionPane.showMessageDialog(null,
                                    "⚠ Message too long! Keep it under 250 characters.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            i--;
                            continue;
                        }

                        Message m = new Message(allMessages.size(), recipient.trim(), messageText);
                        String actionResult = m.sendMessageViaDialog();
                        JOptionPane.showMessageDialog(null, actionResult);

                        if (m.getStatus() == Message.Status.STORED) {
                            try {
                                Message.storeMessagesToJson(
                                        Collections.singletonList(m),
                                        System.getProperty("user.home") + "/stored_messages.json");
                                JOptionPane.showMessageDialog(null,
                                        "💾 Message saved successfully!");
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(null, "❌ Could not save message: " + ex.getMessage());
                            }
                        }

                        JOptionPane.showMessageDialog(null, "✅ " + m.printMessageDetails());
                        allMessages.add(m);
                        messagesSent++;
                    }

                    int totalSent = Message.returnTotalMessages(allMessages);
                    JOptionPane.showMessageDialog(null, "📊 Total messages sent: " + totalSent);
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "🕓 Recent messages feature is coming soon!");
                    break;

                case "3":
                    quit = true;
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "❌ Invalid choice. Please pick 1, 2, or 3.");
            }
        }

        // === GOODBYE MESSAGE ===
        JOptionPane.showMessageDialog(null,
                "👋 Thank you for using TTMQuickChat!\n\nKeep sharing moments that matter ❤\nStay connected, stay kind, stay chatting 💬");
    }
}